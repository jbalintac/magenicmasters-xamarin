﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactManager.Interfaces
{
    public interface IDialerService
    {
        void DialPhoneNumber(string phoneNumber);
    }
}
